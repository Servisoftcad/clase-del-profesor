const numbers2 = [4, 71, 38, 43]
const numbersTriple = numbers.map(number => number * 3)

console.log('Hello World!')