const numbers = [1, 2, 3, 4]
const numbersDouble = numbers.map(number => number * 2)

class Person {
    constructor(name) {
        this.name = name
    }
}

console.log(numbers)