# css2018
Esta es una guía siguiendo los estándares de CSS en 2018/2019. Aquí voy subiendo los repositorios de código del curso que estoy dictando en youtube. Puedes encontrarlo en https://www.youtube.com/playlist?list=PLROIqh_5RZeAoysDfEpB_asxV0cItZOL_
