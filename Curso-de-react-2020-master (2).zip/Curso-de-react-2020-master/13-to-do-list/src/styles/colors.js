const allColors = {
    mainColor: '#387EF5',
    colors: [
        '#5D576B',
        '#33C4FF',
        '#FF3333',
        '#DA33FF'
    ]
}

export default allColors