import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'


ReactDOM.render(<App number={6} name='Dorian' />, document.getElementById('root'));
