import React from 'react'

import './button.scss'

const Button = () => {
    return (
        <button className='button'>Click Me!</button>
    )
}

export default Button
