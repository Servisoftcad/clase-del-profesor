import React, { Component } from 'react'
import Button from './components/Button/Button';

class App extends Component {

    render() {
        return <Button />
    }
}

export default App;