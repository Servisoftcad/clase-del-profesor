import React from 'react'
import Counter from './components/Counter'
// import './reducer';

const App = () => {
  return (
    <>
      <h1>Reducer</h1>
      <Counter />
    </>
  )
}

export default App
