import React, { Component } from 'react'
import Form from './components/Form'
// import Refs from './components/Refs'

class App extends Component {

    render() {
        return <Form />
    }
}

export default App;