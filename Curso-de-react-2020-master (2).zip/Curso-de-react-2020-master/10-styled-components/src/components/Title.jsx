import React from 'react'

const Title = () => {
    return (
        <h1>
            Styled Components
        </h1>
    )
}

export default Title
