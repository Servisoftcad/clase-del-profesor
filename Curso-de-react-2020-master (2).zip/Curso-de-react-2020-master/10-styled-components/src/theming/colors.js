export default {
    primary: 'royalblue',
    danger: 'red'
}