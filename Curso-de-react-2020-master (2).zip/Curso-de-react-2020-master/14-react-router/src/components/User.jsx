import React from 'react';

const User = ({ match }) => {
    // const id = match.params.userId
    return (
        <h1> User </h1>
    )

}
// const User = ({ location }) => {
//     console.log(location);
//     const query = new URLSearchParams(location.search)
//     console.log(query.get('nameasdasd'));
//     return (
//         <>
//             <h1> User </h1>
//         </>
//     )
// }

export default User