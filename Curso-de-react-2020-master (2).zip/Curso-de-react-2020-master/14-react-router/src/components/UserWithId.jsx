import React from 'react';

const UserWithId = () => {
    return (
        <h1> User With Id </h1>
    )

}

export default UserWithId