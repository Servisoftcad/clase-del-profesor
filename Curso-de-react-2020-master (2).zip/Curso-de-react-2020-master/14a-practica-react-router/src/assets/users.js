export const users = [
    {
        "id": 1,
        "name": "Leanne Graham",
        "username": "Bret",
        "email": "Sincere@april.biz",
        "image": "https://randomuser.me/api/portraits/women/66.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 2,
        "name": "Ervin Howell",
        "username": "Antonette",
        "email": "Shanna@melissa.tv",
        "image": "https://randomuser.me/api/portraits/men/56.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 3,
        "name": "Clementine Bauch",
        "username": "Samantha",
        "email": "Nathan@yesenia.net",
        "image": "https://randomuser.me/api/portraits/men/35.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 4,
        "name": "Patricia Lebsack",
        "username": "Karianne",
        "email": "Julianne.OConner@kory.org",
        "image": "https://randomuser.me/api/portraits/women/43.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 5,
        "name": "Chelsey Dietrich",
        "username": "Kamren",
        "email": "Lucio_Hettinger@annie.ca",
        "image": "https://randomuser.me/api/portraits/women/46.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 6,
        "name": "Mrs. Dennis Schulist",
        "username": "Leopoldo_Corkery",
        "email": "Karley_Dach@jasper.info",
        "image": "https://randomuser.me/api/portraits/men/59.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 7,
        "name": "Kurtis Weissnat",
        "username": "Elwyn.Skiles",
        "email": "Telly.Hoeger@billy.biz",
        "image": "https://randomuser.me/api/portraits/men/91.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 8,
        "name": "Nicholas Runolfsdottir V",
        "username": "Maxime_Nienow",
        "email": "Sherwood@rosamond.me",
        "image": "https://randomuser.me/api/portraits/men/82.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 9,
        "name": "Glenna Reichert",
        "username": "Delphine",
        "email": "Chaim_McDermott@dana.io",
        "image": "https://randomuser.me/api/portraits/women/10.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    },
    {
        "id": 10,
        "name": "Clementina DuBuque",
        "username": "Moriah.Stanton",
        "email": "Rey.Padberg@karina.biz",
        "image": "https://randomuser.me/api/portraits/women/77.jpg",
        "description": " Lorem ipsum dolor sit amet consectetur, adipisicing elit. Optio error maxime corrupti vero architecto accusamus voluptatem distinctio est, mollitia soluta ipsa ipsam dolor consequuntur aperiam dolorum maiores corporis cumque id?"
    }
]