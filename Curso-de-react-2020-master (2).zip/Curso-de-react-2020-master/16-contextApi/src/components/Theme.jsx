import React from 'react'

const Theme = () => {
  return (
    <>
      <h1>Theme</h1>
      <button>Dark Theme</button>
      <button>LightTheme</button>
    </>
  )
}

export default Theme
