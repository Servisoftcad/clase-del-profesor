import React from 'react';

const Header = () => (
    <>
        <h1>Soy el Header</h1>
        <h2>Subtítulo del header</h2>
    </>
)

export default Header